
#ifndef RDKH
#define RDKH
#include <Arduino.h>

class RDKAPRS
{
  public:
    RDKAPRS();

    void begin(int p_bf, int f1, int f2, int f3);
    void sendPacket(unsigned char buffer[], unsigned char size_array);
	void sendMessage();  
	void sendLoc(void *_buffer, size_t length);	
    void sinus();
    
	void setCallsign(char *call, int ssid);
	void setDestination(char *call, int ssid);
	void setMessageDestination(char *call, int ssid);
	void setPath1(char *call, int ssid);
	void setPath2(char *call, int ssid);
	void setComment(char *comment);
	
	void setPreamble(byte pre);
	void setTail(byte tail);
	void useAlternateSymbolTable(bool use);
	void setSymbol(char sym);

	void setLat(char *lat);
	void setLon(char *lon);
	void setPower(int s);
	void setHeight(int s);
	void setGain(int s);
	void setDirectivity(int s);    
	void printSettings();
	void createFullMSG();
	void addString(const char *str, bool swap);
	void addChar(byte chr, bool swap, bool Or1);
	void dumpStr(const char *str);
	int freeMemory();
	byte getMessage(char* data);

    unsigned long computeDdsWord(double freq);

    double freq;
    int sync;
    int led;
    int bf;
    double refclk;
    byte flip_freq;
    int msgLoc;

    volatile unsigned long ddsAccu;   // phase accumulator
    volatile unsigned long ddsWord;
    volatile unsigned long ddsWord0;  // dds tuning word 0
    volatile unsigned long ddsWord1;  // dds tuning word 1
    volatile unsigned long ddsWord2;  // dds tuning word 1

    volatile int sinusPtr;
    volatile int countPtr;
    volatile int shift;

    byte ptrStartNmea;

  private:

    int32_t parseDecimal(const char *term);
    int32_t timePrec;
    unsigned int timeElapsed;

    void send_bit(int tempo);
    unsigned char flip;

    byte validNmea(char byteGPS);
    void sendbyte (unsigned char inbyte);
    void fcsbit(unsigned short tbyte);
    void flipout(void);
    void clearGps(void);

    unsigned char stuff, flag, fcsflag;

    unsigned short crc;

    int sentence_status;      //0: recherche $, 1:recherche GPxxx, 2:GPGGA trouvé
    char sentenceType[5 + 1];   //GPxxx
    int ptr;                  //ptr for cahr arrays
    int comma_count;          //count , into sentences
    //byte timeModulo;
};

extern RDKAPRS Beacon;

#endif
