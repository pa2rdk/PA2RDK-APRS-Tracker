
#include <RDKAPRS.h>

RDKAPRS Beacon;

char CALL[7] = "NOCALL";
int CALL_SSID = 0;
char DST[7] = "APZMDM";
int DST_SSID = 0;
char PATH1[7] = "WIDE1";
int PATH1_SSID = 1;
char PATH2[7] = "WIDE2";
int PATH2_SSID = 2;
char COMMENT[16] = "No comment     ";
char FULLMSG[72];
char THISTIME[8] = "162030h";
int msgPos = 0;

char message_recip[7];
int message_recip_ssid = -1;
int msgLoc = *FULLMSG;
int MICE_MSG = 6;

byte custom_preamble = 100;
byte custom_tail = 50;

char latitude[9];
char longitude[10];
char symbolTable = '/';
char symbol = 'n';
char ipacket[10] = "---------";

unsigned long gps_kspeed;
unsigned long gps_course;

uint8_t power = 10;
uint8_t height = 10;
uint8_t gain = 10;
uint8_t directivity = 10;

RDKAPRS::RDKAPRS() {
	ptr = 0;                //ptr for char arrays
	comma_count = 0;        //count , into sentences
	sinusPtr = 0;
	countPtr = 0;
}

void RDKAPRS::begin(int p_bf, int f1, int f2, int f3) {
	bf = p_bf;

	pinMode(bf, OUTPUT);

	analogWrite(bf, 0);      //dds off
	refclk = 13157.9;    // measured

	ddsWord0 = RDKAPRS::computeDdsWord(f1);
	ddsWord1 = RDKAPRS::computeDdsWord(f2);
	ddsWord2 = RDKAPRS::computeDdsWord(f1 - f3);
}

void RDKAPRS::setCallsign(char *call, int ssid) {
	memset(CALL, 0, 7);
	int i = 0;
	while (i < 6 && call[i] != 0) {
		CALL[i] = call[i];
		i++;
	}
	CALL_SSID = ssid;
}

void RDKAPRS::setDestination(char *call, int ssid) {
	memset(DST, 0, 7);
	int i = 0;
	while (i < 6 && call[i] != 0) {
		DST[i] = call[i];
		i++;
	}
	DST_SSID = ssid;
}

void RDKAPRS::setPath1(char *call, int ssid) {
	memset(PATH1, 0, 7);
	int i = 0;
	while (i < 6 && call[i] != 0) {
		PATH1[i] = call[i];
		i++;
	}
	PATH1_SSID = ssid;
}

void RDKAPRS::setPath2(char *call, int ssid) {
	memset(PATH2, 0, 7);
	int i = 0;
	while (i < 6 && call[i] != 0) {
		PATH2[i] = call[i];
		i++;
	}
	PATH2_SSID = ssid;
}

void RDKAPRS::setMessageDestination(char *call, int ssid) {
	memset(message_recip, 0, 7);
	int i = 0;
	while (i < 6 && call[i] != 0) {
		message_recip[i] = call[i];
		i++;
	}
	message_recip_ssid = ssid;
}

void RDKAPRS::setComment(char *comment) {
	memset(COMMENT, 0, 16);
	int i = 0;
	while (i < 15 && comment[i] != 0) {
		COMMENT[i] = comment[i];
		i++;
	}
}

void RDKAPRS::setPreamble(byte pre) {
	custom_preamble = pre;
}

void RDKAPRS::setTail(byte tail) {
	custom_tail = tail;
}

void RDKAPRS::useAlternateSymbolTable(bool use) {
	if (use) {
		symbolTable = '\\';
	} else {
		symbolTable = '/';
	}
}

void RDKAPRS::setSymbol(char sym) {
	symbol = sym;
}

void RDKAPRS::setLat(char *lat) {
	memset(latitude, 0, 9);
	int i = 0;
	while (i < 8 && lat[i] != 0) {
		latitude[i] = lat[i];
		i++;
	}
}

void RDKAPRS::setLon(char *lon) {
	memset(longitude, 0, 10);
	int i = 0;
	while (i < 9 && lon[i] != 0) {
		longitude[i] = lon[i];
		i++;
	}
}

void RDKAPRS::setPower(int s) {
	if (s >= 0 && s < 10) {
		power = s;
	}
}

void RDKAPRS::setHeight(int s) {
	if (s >= 0 && s < 10) {
		height = s;
	}
}

void RDKAPRS::setGain(int s) {
	if (s >= 0 && s < 10) {
		gain = s;
	}
}

void RDKAPRS::setDirectivity(int s) {
	if (s >= 0 && s < 10) {
		directivity = s;
	}
}

void RDKAPRS::setKspeed(unsigned long kspeed) {
	gps_kspeed = kspeed;
}

void RDKAPRS::setCourse(unsigned long course) {
	gps_course = course;
}

void RDKAPRS::printSettings() {
	Serial.println(F("LibAPRS Settings:"));
	Serial.print(F("Callsign:    ")); Serial.print(CALL); Serial.print(F("-")); Serial.println(CALL_SSID);
	Serial.print(F("Destination: ")); Serial.print(DST); Serial.print(F("-")); Serial.println(DST_SSID);
	Serial.print(F("Path1:       ")); Serial.print(PATH1); Serial.print(F("-")); Serial.println(PATH1_SSID);
	Serial.print(F("Path2:       ")); Serial.print(PATH2); Serial.print(F("-")); Serial.println(PATH2_SSID);
	Serial.print(F("Message dst: ")); if (message_recip[0] == 0) { Serial.println(F("N/A")); } else { Serial.print(message_recip); Serial.print(F("-")); Serial.println(message_recip_ssid); }
	Serial.print(F("TX Preamble: ")); Serial.println(custom_preamble);
	Serial.print(F("TX Tail:     ")); Serial.println(custom_tail);
	Serial.print(F("Symbol table:")); if (symbolTable = '/') { Serial.println(F("Normal")); } else { Serial.println(F("Alternate")); }
	Serial.print(F("Symbol:      ")); Serial.println(symbol);
	Serial.print(F("Power:       ")); if (power < 10) { Serial.println(power); } else { Serial.println(F("N/A")); }
	Serial.print(F("Height:      ")); if (height < 10) { Serial.println(height); } else { Serial.println(F("N/A")); }
	Serial.print(F("Gain:        ")); if (gain < 10) { Serial.println(gain); } else { Serial.println(F("N/A")); }
	Serial.print(F("Directivity: ")); if (directivity < 10) { Serial.println(directivity); } else { Serial.println(F("N/A")); }
	Serial.print(F("Latitude:    ")); if (latitude[0] != 0) { Serial.println(latitude); } else { Serial.println(F("N/A")); }
	Serial.print(F("Longitude:   ")); if (longitude[0] != 0) { Serial.println(longitude); } else { Serial.println(F("N/A")); }
	Serial.print(F("Speed Knots: ")); if (latitude[0] != 0) { Serial.println(gps_kspeed); } else { Serial.println(F("N/A")); }
	Serial.print(F("Course:      ")); if (latitude[0] != 0) { Serial.println(gps_course); } else { Serial.println(F("N/A")); }
	Serial.print(F("Longitude:   ")); if (longitude[0] != 0) { Serial.println(longitude); } else { Serial.println(F("N/A")); }
	Serial.print(F("Comment:     ")); Serial.println(COMMENT);
}

extern unsigned int __heap_start;
extern void *__brkval;

struct __freelist {
	size_t sz;
	struct __freelist *nx;
};

extern struct __freelist *__flp;

int freeListSize() {
	struct __freelist* current;
	int total = 0;
	for (current = __flp; current; current = current->nx) {
		total += 2; /* Add two bytes for the memory block's header  */
		total += (int) current->sz;
	}
	return total;
}

int RDKAPRS::freeMemory() {
	int free_memory;
	if ((int)__brkval == 0) {
		free_memory = ((int)&free_memory) - ((int)&__heap_start);
	} else {
		free_memory = ((int)&free_memory) - ((int)__brkval);
		free_memory += freeListSize();
	}
	return free_memory;
}

/********************************************************
   Send a bit into an FM modulation
 ********************************************************/

void RDKAPRS::send_bit(int tempo)
{
	countPtr = 0;
	while (countPtr < tempo) {
	}
}

void RDKAPRS::sinus()
{

	const static byte sinusTable[512] PROGMEM = {128, 129, 131, 132, 134, 135, 137, 138, 140, 141, 143, 145, 146, 148, 149, 151, 152, 154, 155, 157, 158, 160, 161, 163, 164, 166, 167, 169, 170, 172, 173, 175, 176, 178, 179, 180, 182, 183, 185, 186,
			187, 189, 190, 191, 193, 194, 195, 197, 198, 199, 201, 202, 203, 204, 206, 207, 208, 209, 210, 212, 213, 214, 215, 216, 217, 218, 219, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 230, 231, 232,
			233, 234, 235, 236, 236, 237, 238, 239, 240, 240, 241, 242, 242, 243, 244, 244, 245, 245, 246, 247, 247, 248, 248, 249, 249, 249, 250, 250, 251, 251, 251, 252, 252, 252, 253, 253, 253, 253, 254, 254,
			254, 254, 254, 254, 254, 254, 254, 254, 255, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 253, 253, 253, 253, 252, 252, 252, 251, 251, 251, 250, 250, 249, 249, 249, 248, 248, 247, 247, 246, 245,
			245, 244, 244, 243, 242, 242, 241, 240, 240, 239, 238, 237, 236, 236, 235, 234, 233, 232, 231, 230, 230, 229, 228, 227, 226, 225, 224, 223, 222, 221, 219, 218, 217, 216, 215, 214, 213, 212, 210, 209,
			208, 207, 206, 204, 203, 202, 201, 199, 198, 197, 195, 194, 193, 191, 190, 189, 187, 186, 185, 183, 182, 180, 179, 178, 176, 175, 173, 172, 170, 169, 167, 166, 164, 163, 161, 160, 158, 157, 155, 154,
			152, 151, 149, 148, 146, 145, 143, 141, 140, 138, 137, 135, 134, 132, 131, 129, 127, 126, 124, 123, 121, 120, 118, 117, 115, 114, 112, 110, 109, 107, 106, 104, 103, 101, 100, 98, 97, 95, 94, 92, 91, 89,
			88, 86, 85, 83, 82, 80, 79, 77, 76, 75, 73, 72, 70, 69, 68, 66, 65, 64, 62, 61, 60, 58, 57, 56, 54, 53, 52, 51, 49, 48, 47, 46, 45, 43, 42, 41, 40, 39, 38, 37, 36, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 25, 24, 23,
			22, 21, 20, 19, 19, 18, 17, 16, 15, 15, 14, 13, 13, 12, 11, 11, 10, 10, 9, 8, 8, 7, 7, 6, 6, 6, 5, 5, 4, 4, 4, 3, 3, 3, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 6,
			6, 6, 7, 7, 8, 8, 9, 10, 10, 11, 11, 12, 13, 13, 14, 15, 15, 16, 17, 18, 19, 19, 20, 21, 22, 23, 24, 25, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 36, 37, 38, 39, 40, 41, 42, 43, 45, 46, 47, 48, 49, 51, 52, 53, 54, 56, 57,
			58, 60, 61, 62, 64, 65, 66, 68, 69, 70, 72, 73, 75, 76, 77, 79, 80, 82, 83, 85, 86, 88, 89, 91, 92, 94, 95, 97, 98, 100, 101, 103, 104, 106, 107, 109, 110, 112, 114, 115, 117, 118, 120, 121, 123, 124, 126
	};


	ddsAccu = ddsAccu + ddsWord; // soft DDS, phase accu with 32 bits
	sinusPtr = ddsAccu >> 23;
	analogWrite(bf, pgm_read_byte(&(sinusTable[sinusPtr])));
	countPtr++;
}



/********************************************************
   AX25 routines
 ********************************************************/

void RDKAPRS::flipout(void)
{
	stuff = 0;     //since this is a 0, reset the stuff counter
	flip_freq ^= 1;
	if (flip_freq == 0) ddsWord = ddsWord1; else ddsWord = ddsWord0;
}

void RDKAPRS::fcsbit(unsigned short tbyte)
{
	crc ^= tbyte;
	if (crc & 1)
		crc = (crc >> 1) ^ 0x8408;  // X-modem CRC poly
	else
		crc = crc >> 1;
}

void RDKAPRS::sendbyte (unsigned char inbyte)
{
	unsigned char k, bt;
	//Serial.print(inbyte,HEX);

	for (k = 0; k < 8; k++)
	{ //do the following for each of the 8 bits in the byte
		bt = inbyte & 0x01;                                          //strip off the rightmost bit of the byte to be sent (inbyte)
		if ((fcsflag == 0) & (flag == 0)) (RDKAPRS::fcsbit(bt));             //do FCS calc, but only if this is not a flag or fcs byte
		if (bt == 0) (RDKAPRS::flipout());                      // if this bit is a zero, flip the output state
		else {                                //otherwise if it is a 1, do the following:
			stuff++;                           //increment the count of consequtive 1's
			if ((flag == 0) & (stuff == 5))
			{ //stuff an extra 0, if 5 1's in a row
				//flip the output state to stuff a 0
				RDKAPRS::send_bit(11);
				RDKAPRS::flipout();
			}
		}
		inbyte = inbyte >> 1;                            //go to the next bit in the byte
		RDKAPRS::send_bit(11);
	}//fin pour
}

unsigned long RDKAPRS::computeDdsWord(double freq)
{
	return pow(2, 32) * freq / refclk;
}

void RDKAPRS::sendLoc(void *_buffer, size_t length) {
	size_t payloadLength = 20+length;
	bool usePHG = false;
	if (power < 10 && height < 10 && gain < 10 && directivity < 9) {
		usePHG = true;
		payloadLength += 7;
	}
	uint8_t *packet = (uint8_t*)malloc(payloadLength);
	uint8_t *ptr = packet;
	packet[0] = '=';
	packet[9] = symbolTable;
	packet[19] = symbol;
	ptr++;
	memcpy(ptr, latitude, 8);
	ptr += 9;
	memcpy(ptr, longitude, 9);
	ptr += 10;
	if (usePHG) {
		packet[20] = 'P';
		packet[21] = 'H';
		packet[22] = 'G';
		packet[23] = power+48;
		packet[24] = height+48;
		packet[25] = gain+48;
		packet[26] = directivity+48;
		ptr+=7;
	}
	if (length > 0) {
		uint8_t *buffer = (uint8_t *)_buffer;
		memcpy(ptr, buffer, length);
	}

	//Serial.println(packet);

	for (int k = 0; k < payloadLength; k++){
		Serial.write(packet[k]);
	}
	Serial.println(payloadLength);

	RDKAPRS::sendPacket(packet, payloadLength);
	free(packet);
}

void RDKAPRS::sendPacket(unsigned char buffer[], unsigned char size_array)
{
	unsigned char i;
	crc = 0xffff;
	stuff = 0;

	shift = 6;    //init
	flip_freq = 1;
	ddsWord = ddsWord1;

	RDKAPRS::send_bit(11);

	flag = 1;          //The variable flag is true if you are transmitted flags (7E's) false otherwise.
	fcsflag = 0;       //The variable fcsflag is true if you are transmitting FCS bytes, false otherwise.

	for (i = 0; i < custom_preamble; i++) RDKAPRS::sendbyte(0x7E);    //Sends 100 flag bytes.
	flag = 0;                        //done sending flags
	for (i = 0; i < size_array; i++) RDKAPRS::sendbyte(buffer[i]); //send the packet bytes

	fcsflag = 1;           //about to send the FCS bytes
	RDKAPRS::sendbyte((crc ^ 0xff));  // Send the CRC
	crc >>= 8;
	RDKAPRS::sendbyte((crc ^ 0xff));
	fcsflag = 0;   //done sending FCS
	flag = 1;    //about to send flags
	for (i = 0; i < custom_tail; i++) RDKAPRS::sendbyte(0x7E);   //Sends 100 flag bytes.

	//Serial.println("");
	//Serial.println(size_array);
	//for (i = 0; i < size_array; i++) Serial.write(buffer[i]);
	Serial.println();
	RDKAPRS::dumpStr(buffer);
}

void RDKAPRS::sendMessage(){
	RDKAPRS::createFullMSG();
	RDKAPRS::sendPacket(FULLMSG,msgPos);
}

byte RDKAPRS::getMessage(char* data){
	RDKAPRS::createFullMSG();
	const char *p;
	p = FULLMSG;
	int i = 0;
	bool doSwap = 1;

	while (*p) {
		byte b = *p;
		if (b==0x03) doSwap=0;
		if (doSwap==1) data[i] = (b>>1); else data[i]=b;
		p++;
		i++;
	}
	data[i]='\0'; //the data will be in the array in the function which called this one
	return i; //and here we let the caller know how many bytes are in the array.
}

int32_t RDKAPRS::parseDecimal(const char *term)
{
	bool negative = *term == '-';
	if (negative) ++term;
	int32_t ret = 100 * (int32_t)atol(term);
	while (isdigit(*term)) ++term;
	if (*term == '.' && isdigit(term[1]))
	{
		ret += 10 * (term[1] - '0');
		if (isdigit(term[2]))
			ret += term[2] - '0';
	}
	return negative ? -ret : ret;
}

void RDKAPRS::createFullMSG(){
	memset(FULLMSG,0,72);
	msgPos = 0;
	
	DST[0] = (latitude[0] & 0x0F) | 0x30;
    	  if (MICE_MSG & 0x04) {
         if (MICE_MSG & 0x80) {
             DST[0] += 0x17; // Custom message bit
         } else {
             DST[0] += 0x20; // Standard message bit
         }
       }
    	DST[1] = (latitude[1] & 0x0F) | 0x30;
    	  if (MICE_MSG & 0x02) {
         if (MICE_MSG & 0x80) {
             DST[1] += 0x17; // Custom message bit
         } else {
             DST[1] += 0x20; // Standard message bit
         }
       }
    	DST[2] = (latitude[2] & 0x0F) | 0x30;
       if (MICE_MSG & 0x01) {
         if (MICE_MSG & 0x80) {
            DST[2] += 0x17; // Custom message bit
         } else {
            DST[2] += 0x20; // Standard message bit
         }
       }
    	DST[3] = (latitude[3] & 0x0F) | 0x30;
       if (latitude[7] == 'N') { // North/South Latitude Indicator
        DST[3] += 0x20;
       }
     DST[4] = (latitude[5] & 0x0F) | 0x30; // Use latitude[5] because latitude[4] is a .
     DST[5] = (latitude[6] & 0x0F) | 0x30;
       if (longitude[8] == 'W') { // If the longitude is > 100, set this bit
         DST[4] += 0x20;
       }
	DST[6] = 0;

// Destination has been set. Now create information field

	ipacket[0] = 0x60; // The ` character indicating valid GPS data
     uint8_t lon_deg = ((longitude[0] & 0x0F) * 100 + (longitude[1] & 0x0F) * 10 + (longitude[2] & 0x0F));
     if (lon_deg < 10) {
        ipacket[1] = 118 + lon_deg;
        DST[4] += 0x20;
     } else if (lon_deg < 100) {
        ipacket[1] = 38 + lon_deg - 10;
     } else if (lon_deg < 110) {
        ipacket[1] = 108 + (lon_deg - 100);
        DST[4] += 0x20;
     } else {
        ipacket[1] = 38 + (lon_deg - 110);
        DST[4] += 0x20;
     }
     uint8_t lon_min = ((longitude[3] & 0x0F) * 10) + (longitude[4] & 0x0F);
     if (lon_min < 10) {
        ipacket[2] = 88 + lon_min;
     } else {
        ipacket[2] = 38 + lon_min - 10;
     }
     ipacket[3] = ((longitude[6] & 0x0F) * 10) + (longitude[7] & 0x0F) + 28;
     // bytes 4, 5 and 6 encode the speed and course
     // Page 50 of the APRS spec
     ipacket[4] = (gps_kspeed / 10) + 28; // 100's an 10's of knots
     ipacket[5] = (gps_kspeed % 10) * 10 + 32; // 1's of knots
     if (gps_course > 299) {
        ipacket[5] += 3;
     } else if (gps_course > 199) {
        ipacket[5] += 2;
     } else if (gps_course > 99) {
        ipacket[5] += 1;
     }
	ipacket[6] = (gps_course % 100) + 28;
	ipacket[7] = 0;
    
    	addString(DST,1);
	addChar('0'+DST_SSID,1,0);
	addString(CALL,1);
	addChar('0'+CALL_SSID,1,0);
	addString(PATH1,1);
	addChar(' ',1,0);
	addChar('0'+PATH1_SSID,1,0);
	addString(PATH2,1);
	addChar(' ',1,0);
	addChar('0'+PATH2_SSID,1,1);
	addChar(0x03,0,0);
	addChar(0xf0,0,0);
	addString(ipacket,0);
	addChar(symbol,0,0);
	addChar(symbolTable,0,0);
	addChar(']',0,0);
	addString(COMMENT,0);
	addChar('=',0,0);
	FULLMSG[msgPos]=0;

}

void RDKAPRS::addString(const char *str, bool swap) {
	const char *p;
	p = str;

	while (*p) {
		if (swap == 1) FULLMSG[msgPos] = *p << 1; else FULLMSG[msgPos] = *p;
		p++;
		msgPos++;
	}
}

void RDKAPRS::addChar(byte chr, bool swap, bool Or1) {
	if (swap == 1) {
		if (Or1 == 1) FULLMSG[msgPos] = chr << 1|1; else FULLMSG[msgPos] = chr << 1;
	}
	else {
		FULLMSG[msgPos] = chr;
	}
	msgPos++;
}

void RDKAPRS::dumpStr(const char *str) {
	const char *p;
	p = str;
	int i = 0;
	bool doSwap = 1;

	while (*p) {
		byte b = *p;
		if (b==0x03) doSwap=0;
		if (doSwap==1) Serial.write(b>>1); else Serial.write(b);
		p++;
	}
	Serial.println("");

	p = str;
	while (*p) {
		byte b = *p;
		Serial.print(b,HEX);
		p++;
		i++;
	}
	Serial.print(F(" "));
	Serial.print(i);

}





